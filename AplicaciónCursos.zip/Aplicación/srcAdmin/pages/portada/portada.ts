import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { CrearPage } from '../crear/crear';

/**
 * Generated class for the PortadaPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-portada',
  templateUrl: 'portada.html',
})
export class PortadaPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  public inicio() {
  	this.navCtrl.push(LoginPage);//Dirije a la pagina de login
  }

  public registrar() {
  	this.navCtrl.push(CrearPage);//Dirije a la pagina de crear cuenta
  }

}
