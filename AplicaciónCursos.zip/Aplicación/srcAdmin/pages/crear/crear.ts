import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { LoginPage } from '../login/login';

/**
 * Generated class for the CrearPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crear',
  templateUrl: 'crear.html',
})
export class CrearPage {

	usuario="";//Se crea una variable para alojar el contenido del formulario
	contrase="";//Se crea una variable para alojar el contenido del formulario

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  public guardar() {
  	this.navCtrl.push(LoginPage, {contrase:this.contrase, usuario:this.usuario});
  }//Funcion que nos envia a la pagina de login pasando la contraseña y el ususrio
  //que introdujo el administrador

}
