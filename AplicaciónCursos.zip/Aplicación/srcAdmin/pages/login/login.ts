import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';


/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

	usuario = "";//Se crea esta variable para almacenar los dtos enviados desde otra pagina
	contrase = "";//Se crea esta variable para almacenar los dtos enviados desde otra pagina
	user="";//Variable para gusrdar los datos de este formulario
	pass="";//Variable para gusrdar los datos de este formulario

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.usuario=navParams.get('usuario');//Se obtiene el usuario y se le asigna a la variable antes declarada
    this.contrase=navParams.get('contrase');//Se obtiene el usuario y se le asigna a la variable antes declarada
  }

  IniciarSesion(){
  		if (this.user == this.usuario && this.pass == this.contrase) {//Condicion para ver si el usuario y la contraseña son iguales
  			this.navCtrl.push(HomePage);//Si son iguales nos dirije a la pagina de home
  			console.log("Ingresado bien");
  		} else {
  			console.log("Acceso denegado");//Si no se muestra un mensaje de error
  		}
  	}

}
