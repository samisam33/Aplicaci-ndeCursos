import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';
import { Detail2Page } from '../detail2/detail2';

/**
 * Generated class for the DetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail',
  templateUrl: 'detail.html',
})
export class DetailPage {

	taller:any = {id: null, title: null, nInstructor: null, description: null, temario: null,
					duracion: null, fic: null, ftc: null, hc1: null, hc2: null, fii: null,
					fti: null, lugar: null, maximo: null, minimo: null, costo: null, observaciones: null};
          //Se crea el objeto donde recibira todos los valores del formulario
	id = null; //Se crea una variable para recibir el parametro enviado id

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  	this.id = navParams.get('id');//Obtiene el id de la nota que se seleccione
  	if(this.id != 0) {
  		notesService.getTaller(this.id)//Obitiene el taller a traves del ID 
  		.valueChanges().subscribe( taller => {
  			console.log(taller)//Muestra el contenido del taller en la consola 
  			this.taller = taller;
  		});
  	}
  }

  agregarTaller() {
  	if(this.id != 0) {//Si el id es diferente de cero
  		//editando
  		this.notesService.editarTaller(this.taller);//Se llama la funcion editar taller de la clase notesService
  		alert("Taller editado con exito!");//Se envia una alerta para indicar se edito
  	} else { //Si no es dirente de cero
  		//this.taller.id = Date.now();//Genera un ID
  		this.notesService.crearTaller(this.taller);//Se llama la funcion crear taller 
  		alert("Taller creado con exito!");
  	}
  	this.navCtrl.pop();//Nos regresa a una pagina anterior
  }

  eliminarTaller() {
  	this.notesService.eliminarTaller(this.taller);//Se llama a la funcion eliminar enviando
  	alert("Taller eliminado con exito!");//Los datos del taller
  	this.navCtrl.pop();//Nos regresa una pagina antes
  }

  verRegistros() {
    this.navCtrl.push(Detail2Page, {id:0});//Nos dirije a otra pagina enviando como id cero
  }

}
