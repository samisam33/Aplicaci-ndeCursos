import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';

/**
 * Generated class for the Detail3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail3',
  templateUrl: 'detail3.html',
})
export class Detail3Page {

	registro:any = {id: null, nombre: null, aP: null, aM: null, email: null,
					cO: null, telefono: null};//Se crea un objeto para recibir los datos del formulario
	id = null;//Se crea una variable a la cual se le asignara el id enviado desde otra clase

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  	this.id = navParams.get('id');//Obtiene el id de la nota que se seleccione
  	if(this.id != 0) {//Si id es diferente de cero
  		notesService.getRegistro(this.id)//Se llama a la funcion getRegistro de la clase notesService
  		.valueChanges().subscribe( registro => {//Se muestran los dats en el formulario
  			console.log(registro)//Se muestran los datos en la consola
  			this.registro = registro;
  		});
  	}
  }

  agregarRegistro() {
  	if(this.id != 0) {//Si el id es diferente de cero
  		//editando
  		this.notesService.editarRegistro(this.registro);//Se llama la funcion editar registro de la clase notesService
  		alert("Registro editado!");//Se envia una alerta para indicar se edito
  	} else {//Si no es dirente de cero
  		//this.registro.id = Date.now();//Genera un ID
  		this.notesService.crearRegistro(this.registro);//Se llama la funcion crear taller 
  		alert("Registro creado con exito!");
  	}
  	this.navCtrl.pop();//Nos regresa a una pagina anterior
  }

  eliminarRegistro() {
  	this.notesService.eliminarRegistro(this.registro);//Se llama a la funcion eliminar enviando
  	alert("Registro eliminado con exito!");//Los datos del taller
  	this.navCtrl.pop();
  }

}
