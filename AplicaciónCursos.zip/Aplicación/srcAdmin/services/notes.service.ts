import { Injectable } from '@angular/core';//Sirve para llamar este elemento en cualquier lado del proyecto
//Servicio para los talleres 
import { AngularFireDatabase } from '@angular/fire/database';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class NotesService{

	constructor(public afDB: AngularFireDatabase) {
		//this.notes = afDB.list('cuisines').valueChanges();

	}

	notes = [];
	notes2 = [];
	public getTalleres() {
		//return this.notes;
		return this.afDB.list('notas/').valueChanges();//Obtiene la lista de los talleres que estan en fire base
	}

	public getTaller(id) {
		//return this.notes.filter(function(e, i){return e.id == id})[0] || {id: null, title: null, descripcion: null};
		return this.afDB.object('notas/'+id);//Obtiene cada uno de los talleres pasandole el ID y los trae como objetos
	}

	public crearTaller(taller) {
		this.afDB.database.ref('notas/'+taller.id).set(taller);
		//this.notes.push(note);
	}

	public editarTaller(taller) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes[i] = note;
			}
		}*/
		this.afDB.database.ref('notas/'+taller.id).set(taller);
	}

	public eliminarTaller(taller) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes.splice(i, 1);
			}
		}*/
		this.afDB.database.ref('notas/'+taller.id).remove();	
	}
	////////////////////////////
	public getRegistros() {
		//return this.notes;
		
		return this.afDB.list('notas/1526132/').valueChanges();
	}

	public getRegistro(id) {
		//return this.notes.filter(function(e, i){return e.id == id})[0] || {id: null, title: null, descripcion: null};
		return this.afDB.object('notas/1526132/'+id);
	}

	public crearRegistro(registro) {
		this.afDB.database.ref('notas/1526132/'+registro.id).set(registro);
		//this.notes.push(note);
	}

	public editarRegistro(registro) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes[i] = note;
			}
		}*/
		this.afDB.database.ref('notas/1526132/'+registro.id).set(registro);
	}

	public eliminarRegistro(registro) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes.splice(i, 1);
			}
		}*/
		this.afDB.database.ref('notas/1526132/'+registro.id).remove();	
	}
}