import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { NotesService } from '../services/notes.service';
import { DetailPage } from '../pages/detail/detail';
import { Detail2Page } from '../pages/detail2/detail2';
import { PortadaPage } from '../pages/portada/portada';

import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule, AngularFireDatabase } from '@angular/fire/database';
import { AngularFireAuthModule } from '@angular/fire/auth';

export const firebaseConfig = {
  apiKey: "AIzaSyBzFHlrSs-jZvmJMm6bqxHgliBv8ioxn9M",
  authDomain: "miproyecto-c6e62.firebaseapp.com",
  databaseURL: "https://miproyecto-c6e62.firebaseio.com",
  storageBucket: "miproyecto-c6e62.appspot.com",
  messagingSenderId: '92781952349'
};

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    DetailPage,
    Detail2Page,
    PortadaPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    DetailPage,
    Detail2Page,
    PortadaPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    NotesService
  ]
})
export class AppModule {}
