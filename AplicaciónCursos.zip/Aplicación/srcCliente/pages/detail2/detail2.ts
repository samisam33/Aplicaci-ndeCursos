import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';
import { HomePage } from '../home/home';

/**
 * Generated class for the Detail2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail2',
  templateUrl: 'detail2.html',
})
export class Detail2Page {

	registro:any = {id: null, nombre: null, aP: null, aM: null, email: null, cO: null, telefono: null};
	//id: null;

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
    //this.id = navParams.get('id');
  }

  /*ionViewDidLoad() {
    console.log('ionViewDidLoad Detail2Page');
  }*/

  public reg() {
  	//this.registro.id = Date.now();//Genera un ID
  	this.notesService.registrarme(this.registro);
  	alert("Registro Exitoso!");
  	this.navCtrl.push(HomePage);
  }
}
