import { Injectable } from '@angular/core';//Sirve para llamar este elemento en cualquier lado del proyecto
//Servicio para los talleres 
import { AngularFireDatabase } from '@angular/fire/database';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class NotesService{

	id = null;

	constructor(public afDB: AngularFireDatabase){
		//this.notes = afDB.list('cuisines').valueChanges();
	}

	//notes = [];
	public getTalleres() {
		//return this.notes;
		return this.afDB.list('notas/').valueChanges();
	}

	public getTaller(id) {
		//return this.notes.filter(function(e, i){return e.id == id})[0] || {id: null, title: null, descripcion: null};
		return this.afDB.object('notas/'+id);
		//this.id = id;
	}

	public registrarme(registro) {
		this.afDB.database.ref('notas/1526132/'+registro.id).set(registro);
		//this.notes.push(note);
	}
}